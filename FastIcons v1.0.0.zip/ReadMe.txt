=================
FastIcons V1.0.0
=================
Made By : Ademkouki
Github : https://github.com/Ademking/FastIcons/
Facebook : https://www.facebook.com/AdemKouki.Officiel
